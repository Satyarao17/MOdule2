import {Mobile} from './mobile';

export class BasicPhone extends Mobile{
    mobtype:string;

    constructor (mobId:number,mobName:string,
    mobCost:number,mobtype:string){
        super(mobId,mobName,mobCost);
        this.mobtype=mobtype
    }
}