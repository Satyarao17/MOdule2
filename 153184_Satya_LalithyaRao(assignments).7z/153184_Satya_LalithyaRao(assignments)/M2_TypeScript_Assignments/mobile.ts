export class Mobile{
    mobId:number;
    mobName:string;
    mobCost:number;
    constructor(mobileId:number,mobileName:string,
    mobileCost:number){
        this.mobId=mobileId;
        this.mobName=mobileName;
        this.mobCost=mobileCost;
    }
    printMobileDetail(){
    for(let key in this){
        if(typeof this[key]!='function'){
            console.log(`${key} - ${this[key]}`)
        }
    }
    }
}