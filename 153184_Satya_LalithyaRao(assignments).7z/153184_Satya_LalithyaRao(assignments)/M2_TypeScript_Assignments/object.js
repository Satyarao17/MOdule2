"use strict";
exports.__esModule = true;
var smartphone_1 = require("./smartphone");
var Samsung1 = new smartphone_1.SmartPhone(1001, "samsung", 25000, "C7 pro");
Samsung1.printMobileDetail();
