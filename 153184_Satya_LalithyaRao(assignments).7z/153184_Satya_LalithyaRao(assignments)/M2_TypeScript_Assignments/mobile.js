"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile(mobileId, mobileName, mobileCost) {
        this.mobId = mobileId;
        this.mobName = mobileName;
        this.mobCost = mobileCost;
    }
    Mobile.prototype.printMobileDetail = function () {
        for (var key in this) {
            if (typeof this[key] != 'function') {
                console.log(key + " - " + this[key]);
            }
        }
    };
    return Mobile;
}());
exports.Mobile = Mobile;
