import {Mobile} from './mobile';
import {BasicPhone} from './basicPhone';
import {SmartPhone} from './smartphone';

var Samsung1=new SmartPhone(1001,"samsung",25000,"C7 pro");
Samsung1.printMobileDetail();
