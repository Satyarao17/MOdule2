import {Mobile} from './mobile';

export class SmartPhone extends Mobile{
    mobtype:string;
    constructor (mobId:number,mobName:string,
    mobCost:number,mobtype:string){
        super(mobId,mobName,mobCost);
        this.mobtype=mobtype
    }
    printMobileDetail1():void{
        console.log(this.mobtype);
    }
}