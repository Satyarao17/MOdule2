import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'Angular 2 operation';
  id: number;
  name: string;
  salary: number;
  department: string;
  empid: number;
  empname: string;
  empsalary: number;
  empdepartment: string;
  i: number;
  empArr = [
    { empId: 1001, empName: "Rahul", empSal: 9000, empDep: "Java" },
    { empId: 1002, empName: "Sachin", empSal: 19000, empDep: "OraApps" },
    { empId: 1003, empName: "Vikash", empSal: 29000, empDep: "BI" },
  ];
  addToArray(): any {
    this.empArr.push({ empId: this.id, empName: this.name, empSal: this.salary, empDep: this.department });
  }
  update(index): void {
    this.empArr.splice(index, 1, { empId: this.id, empName: this.name, empSal: this.salary, empDep: this.department });
  }
  delete(index): void {
    this.empArr.splice(index, 1);
  }
}
