import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AngulardisplayComponent } from './angulardisplay.component';

describe('AngulardisplayComponent', () => {
  let component: AngulardisplayComponent;
  let fixture: ComponentFixture<AngulardisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AngulardisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AngulardisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
