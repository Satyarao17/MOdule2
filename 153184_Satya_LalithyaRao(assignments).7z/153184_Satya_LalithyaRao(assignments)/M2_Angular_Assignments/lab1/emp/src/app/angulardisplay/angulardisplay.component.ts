import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angulardisplay',
  templateUrl: './angulardisplay.component.html',
  styleUrls: ['./angulardisplay.component.css']
})
export class AngulardisplayComponent implements OnInit {
id:number;
name:string;
salary:number;
department:string;

  constructor() { }
  display():void
  { 
    alert(this.id+" "+this.name+" "+this.salary+" "+this.department);
    
  }
  ngOnInit() {
  }

}
