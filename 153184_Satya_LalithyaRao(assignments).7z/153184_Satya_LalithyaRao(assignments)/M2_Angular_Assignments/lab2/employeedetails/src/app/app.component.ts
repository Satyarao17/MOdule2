import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular 2 operation';
  id: number;
  name: string;
  salary: number;
  department: string;
  empid: number;
  empname: string;
  empsalary: number;
  empdepartment: string;
  i: number;

  empArr = [
    { empId: 1001, empName: "Rahul", empSal: 9000, empDep: "Java" },
    { empId: 1002, empName: "Sachin", empSal: 19000, empDep: "OraApps" },
    { empId: 1003, empName: "Vikash", empSal: 29000, empDep: "BI" },
  ];
  addToArray(): any {
    this.empArr.push({ empId: this.id, empName: this.name, empSal: this.salary, empDep: this.department });
  }
   update(emp, i): void {
      this.i = i
      this.empid=emp.empId
      this.empname=emp.empName
      this.empsalary=emp.empSal
      this.empdepartment=emp.empDep

  }
  delete(i): void {
    this.empArr.splice(i, 1);
  }
  updateRow() {
    this.empArr[this.i] = {
      empId: this.empid,
      empName: this.empname,
      empSal: this.empsalary,
      empDep: this.empdepartment
    }
  }
}
