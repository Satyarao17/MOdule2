import { Component, OnInit } from '@angular/core';
import { Books } from './books'
import { BooklistService } from '../booklist.service'
@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BookComponent implements OnInit {
  booklist: Books[] = []

  qId:string
  qTitle:string
  qAuthor:string
  qYear:string

  constructor(private booklistService: BooklistService) {
    this.qId = ''
    this.qTitle = ''
    this.qAuthor = ''
    this.qYear = ''
   }
  getBooklist() {
    this.booklistService.getBooklist().subscribe(
      (booklist:Books[]) => this.booklist = booklist
      )
  }
  ngOnInit() {
    this.getBooklist()
  }


  
}
