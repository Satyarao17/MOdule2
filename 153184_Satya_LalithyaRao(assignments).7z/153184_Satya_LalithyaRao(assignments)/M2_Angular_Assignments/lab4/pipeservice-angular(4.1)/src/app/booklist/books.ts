export interface Books {
    id: number,
    title: string,
    year: number,
    author: string
}
