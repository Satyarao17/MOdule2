import { Pipe, PipeTransform } from "@angular/core";
import { Books } from "./books";
@Pipe({
  name: "filter"
})
export class FilterPipe implements PipeTransform {
  transform(value: Books[], Query: string, filterBy: string): Books[] {
    if (filterBy == "id") {
      let idNumber: number = Query ? +Query : null;
      return idNumber ? value.filter((books: Books) => books.id == idNumber) : value;
    }

    if (filterBy == "year") {
      let year = Query ? Query : null;
      return Query
        ? value.filter((books: Books) => String(books.year).indexOf(year) != -1)
        : value;
    }

    Query = Query ? Query.toLocaleLowerCase() : null;
    return Query
      ? value.filter(
          (books: Books) =>
            books[filterBy].toLocaleLowerCase().indexOf(Query) != -1
        )
      : value;
  }
}
