import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { FilterPipe } from './booklist/filter.pipe';
import { BookComponent } from './booklist/booklist.component';
import { AppComponent } from './app.component';
@NgModule({
  declarations: [
    AppComponent,
    BookComponent,
    FilterPipe,
      ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
