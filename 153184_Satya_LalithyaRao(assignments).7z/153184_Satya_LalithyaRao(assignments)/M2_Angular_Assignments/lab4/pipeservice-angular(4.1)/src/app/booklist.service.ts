import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

import { Books } from './booklist/books'

@Injectable({
  providedIn: 'root'
})
export class BooklistService {
  booklistsUrl = 'assets/booklist.json'
  
  constructor(private http: HttpClient) { }

  getBooklist() {
    return this.http.get<Books[]>(this.booklistsUrl)
  }
}
