import { Component, OnInit} from '@angular/core';
import {FormGroup,  FormBuilder} from '@angular/forms';
import {Validators, NgForm} from '@angular/forms';

@Component({
 selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  productForm:FormGroup;
  ProId:number;
  ProName:string="";
  ProCost:number;
  ProOnline:string="";
  ProCategory:string="";
Proavailable:string="";
  constructor( private frmBuilder : FormBuilder) { 
    this.productForm = frmBuilder.group({
      ProId: ['',Validators.compose([Validators.required,Validators.maxLength(4)])],
      ProName: ['',[Validators.required,Validators.maxLength(19)]],
      ProCost: ['',Validators.required],
      ProOnline:['',Validators.required],
      ProCategory: ['',Validators.required],
    Proavailable: ['',Validators.required]
    });
  }
  ngOnInit(){

  }

  onSubmit(prodForm:NgForm) {
    document.getElementById('info').innerHTML = "Press F12 to view the result";
    console.log(this.productForm.value);
  }
}