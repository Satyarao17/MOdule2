import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from '@angular/router';
import {ReactiveFormsModule, FormsModule, Validators} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {FormServiceService} from './form-service.service';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent  
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot([ {
     path: '',
     component : AppComponent
   }])
    ],
  providers: [FormServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
