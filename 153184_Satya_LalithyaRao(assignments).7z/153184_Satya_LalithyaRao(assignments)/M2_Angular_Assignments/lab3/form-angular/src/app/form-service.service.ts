import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FormServiceService {

  constructor() { }
  isIdValid(control){
    return control => {
      var regex = /[0-9]{5}/
      return regex.test(control.value) ? null : { invalidId: true };
    }
  }


}
